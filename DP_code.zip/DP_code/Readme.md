## Step 1. Create python 3.7 environment
conda create -m -n envname python=3.7
## Step 2. Install packages
pip install -r requirements.txt
## Step 3. Run PATE
python PATE_final.py
## Step 4. Run DP-SGD
python DPSGD_final.py